package kh.pet.staticInfo;

public class Message_Configuration {
	public static final int RECORD_COUNT_PER_PAGE = 5; //한 페이지에 보여줄 게시물의 갯수.
	public static final int NAVI_COUNT_PAGE = 3; //한 페이지에 네비게이터는 총 몇 개를 보여줄 것인가.
}
