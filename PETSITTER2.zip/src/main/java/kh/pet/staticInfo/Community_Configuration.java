package kh.pet.staticInfo;

import org.springframework.stereotype.Component;

@Component
public class Community_Configuration {
	public static final int NAVI_COUNT_PER_PAGE = 5;
	public static final int RECORD_COUNT_PER_PAGE = 5;
}
