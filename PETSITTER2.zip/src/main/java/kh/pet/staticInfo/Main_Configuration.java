package kh.pet.staticInfo;

public class Main_Configuration {
public static int naviCountPerPage = 10;
public static int recordCountPerPage = 10;
}
