package kh.pet.staticInfo;

public class  PetSitterConfiguration{
	public static int recordPerPage=10;
	public static int naviPerPage=5;
}