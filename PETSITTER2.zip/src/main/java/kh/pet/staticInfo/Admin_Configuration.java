package kh.pet.staticInfo;

public class Admin_Configuration {
	public static final int member_RECORD_COUNT_PER_PAGE = 5; //한 페이지에 보여줄 게시물의 갯수.
	public static final int member_NAVI_COUNT_PAGE = 3; //한 페이지에 네비게이터는 총 몇 개를 보여줄 것인가.
}
