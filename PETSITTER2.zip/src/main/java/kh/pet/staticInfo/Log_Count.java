package kh.pet.staticInfo;

public class Log_Count {
	public static int log_count = 0;
}
