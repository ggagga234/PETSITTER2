package kh.pet.dto;

public class ServiceDto {
	private String service;

	public ServiceDto(String service) {
		super();
		this.service = service;
	}

	public ServiceDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}
	
	
}
