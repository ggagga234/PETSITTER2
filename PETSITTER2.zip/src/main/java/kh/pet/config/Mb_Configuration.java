package kh.pet.config;

public class Mb_Configuration {
	public static int naviCountPerPage = 5;
	public static int recordCountPerPage = 10;
}
